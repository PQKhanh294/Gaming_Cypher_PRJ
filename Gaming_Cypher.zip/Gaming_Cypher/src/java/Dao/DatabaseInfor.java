package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DatabaseInfor {
    private static final String DB_URL = "jdbc:sqlserver://localhost:1433;databaseName=Gaming_cypher";
    private static final String USER = "sa";
    private static final String PASSWORD = "your_password";

    /**
     * Kết nối tới cơ sở dữ liệu SQL Server
     * @return Connection đối tượng kết nối
     */
    public static Connection getConnection() {
        Connection connection = null;
        try {
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
            connection = DriverManager.getConnection(DB_URL, USER, PASSWORD);
            System.out.println("Kết nối thành công!");
        } catch (ClassNotFoundException | SQLException e) {
            System.err.println("Kết nối thất bại: " + e.getMessage());
        }
        return connection;
    }
}
